// secret-key.js
require('dotenv').config();

module.exports = process.env.JWT_SECRET;
