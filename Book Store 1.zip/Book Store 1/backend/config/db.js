module.exports = {
    HOST: 'localhost',
    USER: 'root',
    PASSWORD: '',
    DATABASE: 'bookstore1',
    DIALECT: 'mysql'
}