// routes/orderItem.js
// const express = require('express');
// const router = express.Router();
// const orderItemsController = require('../controllers/orderItemController');

// router.post('/:orderId/items', orderItemsController.addItemToOrder);
// router.put('/:orderId/items/:itemId', orderItemsController.updateItemInOrder);
// router.delete('/:orderId/items/:itemId', orderItemsController.deleteItemFromOrder);

// module.exports = router;
